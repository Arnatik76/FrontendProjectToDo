import { useState, useEffect } from 'react';
import styles from './styles/App.module.css';
import TaskList from './components/TaskList';
import TaskForm from './components/TaskForm';
import PomodoroTimer from './components/PomodoroTimer';

function App() {
  const [tasks, setTasks] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all'); // all | in-progress | completed
  const [isDark, setIsDark] = useState(false);
  const [isBreak, setIsBreak] = useState(false);


  useEffect(() => {
    const savedTasks = localStorage.getItem('tasks');
    if (savedTasks) {
      try {
        const parsedTasks = JSON.parse(savedTasks);
        if (Array.isArray(parsedTasks)) {
          setTasks(parsedTasks.map(task => ({
            id: task.id || Date.now() + Math.random(), // Если id нет — создаём новый
            text: task.text || 'Без названия',
            status: task.status || 'in-progress',
          })));
        }
      } catch (error) {
        console.error('Ошибка при загрузке задач:', error);
      }
    }
  }, []);
  
  useEffect(() => {
    if (tasks.length > 0) {
      localStorage.setItem('tasks', JSON.stringify(tasks));
    }
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem('theme', isDark ? 'dark' : 'light');
    document.body.classList.toggle(styles.darkTheme, isDark);
  }, [isDark]);

  const toggleTheme = () => {
    setIsDark((prev) => !prev);
  };

  const addTask = (newTask) => {
    if (!newTask || typeof newTask !== 'string') return;
  
    const newTaskObject = {
      id: Date.now(),
      text: newTask.trim(),
      status: 'in-progress',
    };
  
    setTasks([...tasks, newTaskObject]);
  };
  
  const deleteTask = (taskId) => {
    setTasks(tasks.filter(task => task.id !== taskId));
  };
  
  const editTask = (taskId, newText) => {
    setTasks(tasks.map(task =>
      task.id === taskId ? { ...task, text: newText } : task
    ));
  };
  
  const toggleStatus = (taskId) => {
    setTasks(tasks.map(task => {
      if (task.id === taskId) {
        return { ...task, status: task.status === 'in-progress' ? 'completed' : 'in-progress' };
      }
      return task;
    }));
  };
  
  

  const filteredTasks = tasks
    .filter(task => task.text.toLowerCase().includes(searchTerm.toLowerCase()))
    .filter(task => filterStatus === 'all' || task.status === filterStatus);

  return (
    <div className={styles.container}>
      <div className={styles.containerTimer}>
        <PomodoroTimer isDark={isDark} onModeChange={setIsBreak} />
      </div>
      <div className={styles.containerTodo}>
        <h1>To-Do List</h1>
        <button className={styles.themeToggle} onClick={toggleTheme}>
          {isDark ? '🌞 Светлая' : '🌙 Тёмная'}
        </button>

        <input
          type="text"
          placeholder="🔍 Поиск задач..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className={styles.searchInput}
        />

        <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className={styles.filterSelect}>
          <option value="all">Все</option>
          <option value="in-progress">В процессе</option>
          <option value="completed">Выполнено</option>
        </select>

        <TaskForm addTask={addTask} />
        <TaskList 
          tasks={filteredTasks} 
          deleteTask={deleteTask} 
          editTask={editTask} 
          toggleStatus={toggleStatus} 
          isBreak={isBreak} 
        />
      </div>
    </div>
  );
}

export default App;
