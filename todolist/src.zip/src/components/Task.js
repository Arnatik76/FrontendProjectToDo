import styles from '../styles/Task.module.css';

function Task({ task, onDelete, onEdit, onToggleStatus, isBreak }) {
  return (
    <li className={`${styles.task} ${task.status === 'completed' ? styles.completed : ''} ${isBreak ? styles.disabled : ''}`}>
      <span onClick={onToggleStatus} className={styles.taskText}>
        {task.text} {task.status === 'completed' ? '✔' : ''}
      </span>
      {task.status !== 'completed' && (
        <button className={styles.editButton} onClick={onEdit} disabled={isBreak}>✏️</button>
      )}
      
      <button className={styles.deleteButton} onClick={onDelete} disabled={isBreak}>🗑</button>
    </li>
  );
}

export default Task;
